﻿/*
  Runtime compatibility fixes:
  - Robust mobile menu toggle across page variants
  - Auto clear localhost service workers/cache once
*/
(function () {
  "use strict";

  function setupMobileMenu() {
    var menuToggle =
      document.getElementById("mobile-menu-toggle") ||
      document.getElementById("mobileMenuBtn") ||
      document.querySelector(".mobile-menu-toggle") ||
      document.querySelector(".mobile-menu-btn");

    var menu =
      document.getElementById("nav-menu") ||
      document.getElementById("mainMenu") ||
      document.querySelector(".nav-menu") ||
      document.querySelector(".mobile-nav");

    if (!menuToggle || !menu) return;

    if (!menu.id) menu.id = "runtime-mobile-menu";
    menuToggle.setAttribute("aria-controls", menu.id);
    if (!menuToggle.hasAttribute("aria-expanded")) menuToggle.setAttribute("aria-expanded", "false");

    // Ensure mobile panel is visible when active on small screens.
    var style = document.createElement("style");
    style.textContent = [
      "@media (max-width: 900px) {",
      "  .nav-menu.active, #mainMenu.show, .mobile-nav.show, #runtime-mobile-menu.active {",
      "    display: flex !important;",
      "    visibility: visible !important;",
      "    opacity: 1 !important;",
      "    z-index: 2000 !important;",
      "  }",
      "}",
    ].join("\n");
    document.head.appendChild(style);

    function openMenu() {
      menu.classList.add("active");
      menu.classList.add("show");
      menuToggle.classList.add("active");
      menuToggle.setAttribute("aria-expanded", "true");
    }

    function closeMenu() {
      menu.classList.remove("active");
      menu.classList.remove("show");
      menuToggle.classList.remove("active");
      menuToggle.setAttribute("aria-expanded", "false");
    }

    menuToggle.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      var expanded = menuToggle.getAttribute("aria-expanded") === "true";
      if (expanded) closeMenu();
      else openMenu();
    });

    document.addEventListener("click", function (e) {
      if (!menu.contains(e.target) && !menuToggle.contains(e.target)) closeMenu();
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeMenu();
    });

    window.addEventListener("resize", function () {
      if (window.innerWidth > 900) closeMenu();
    });
  }

  function normalizeNavbarUI() {
    var style = document.createElement("style");
    style.textContent = [
      ":root { --nav-height: 76px; }",
      "header, .header {",
      "  min-height: var(--nav-height) !important;",
      "  background: #ffffff !important;",
      "  border-bottom: 1px solid #e2e8f0 !important;",
      "  box-shadow: 0 6px 20px rgba(15, 23, 42, 0.08) !important;",
      "}",
      ".header .container, header .container, .header-container {",
      "  display: flex !important;",
      "  align-items: center !important;",
      "  justify-content: space-between !important;",
      "  gap: 18px !important;",
      "}",
      ".logo img, .brand-logo img, .logo-image {",
      "  height: 44px !important;",
      "  width: auto !important;",
      "  max-width: 180px !important;",
      "  object-fit: contain !important;",
      "  background: #ffffff !important;",
      "  padding: 4px !important;",
      "  border-radius: 8px !important;",
      "  display: block !important;",
      "}",
      ".nav-menu, .main-menu, .mobile-nav {",
      "  list-style: none !important;",
      "  margin: 0 !important;",
      "  padding: 0 !important;",
      "}",
      ".nav-link, .nav-menu a, .main-menu a, .mobile-nav a {",
      "  font-weight: 600 !important;",
      "  color: #243b53 !important;",
      "  text-decoration: none !important;",
      "}",
      ".mobile-menu-toggle, .mobile-menu-btn {",
      "  width: 44px !important;",
      "  height: 44px !important;",
      "  border: 1px solid #cbd5e1 !important;",
      "  border-radius: 10px !important;",
      "  background: #ffffff !important;",
      "}",
      "@media (max-width: 900px) {",
      "  .nav-menu, .main-menu, .mobile-nav {",
      "    position: absolute !important;",
      "    top: calc(var(--nav-height) - 2px) !important;",
      "    left: 12px !important;",
      "    right: 12px !important;",
      "    background: #ffffff !important;",
      "    border: 1px solid #dbe3ec !important;",
      "    border-radius: 12px !important;",
      "    box-shadow: 0 16px 34px rgba(15, 23, 42, 0.18) !important;",
      "    padding: 8px !important;",
      "    z-index: 2100 !important;",
      "    max-height: min(72vh, 520px) !important;",
      "    overflow-y: auto !important;",
      "  }",
      "  .nav-menu li, .main-menu li, .mobile-nav li { width: 100% !important; }",
      "  .nav-link, .nav-menu a, .main-menu a, .mobile-nav a {",
      "    display: block !important;",
      "    padding: 12px 14px !important;",
      "    border-radius: 8px !important;",
      "  }",
      "  .nav-link:hover, .nav-menu a:hover, .main-menu a:hover, .mobile-nav a:hover {",
      "    background: #f1f5f9 !important;",
      "  }",
      "  .nav-menu:not(.active):not(.show), .main-menu:not(.active):not(.show), .mobile-nav:not(.active):not(.show) {",
      "    display: none !important;",
      "  }",
      "}",
    ].join("\n");
    document.head.appendChild(style);
  }

  function enforceLogoFallback() {
    var logoPath = window.location.pathname.includes("/TicketingSystem/frontend/")
      ? "../../images/logo-main.png"
      : "images/logo-main.png";

    var logos = document.querySelectorAll("img[src*='logo'], .logo img, .brand-logo img");
    logos.forEach(function (img) {
      img.addEventListener("error", function () {
        img.src = logoPath;
      });
      if (img.complete && img.naturalWidth === 0) {
        img.src = logoPath;
      }
    });
  }

  function applyGeneratedImagePolish() {
    var style = document.createElement("style");
    style.textContent = [
      "img[src*='images/generated/'] {",
      "  display: block !important;",
      "  max-width: 100% !important;",
      "  height: auto !important;",
      "  border: 0 !important;",
      "  border-radius: 14px !important;",
      "  box-shadow: 0 10px 28px rgba(15, 23, 42, 0.18) !important;",
      "  background: transparent !important;",
      "  object-fit: contain !important;",
      "  clip-path: inset(2px round 14px) !important;",
      "  image-rendering: auto !important;",
      "  -webkit-transform: translateZ(0);",
      "  transform: translateZ(0);",
      "}",
      ".image-container,",
      ".about-image,",
      ".service-card {",
      "  overflow: hidden;",
      "  border-radius: 14px;",
      "}",
      "@media (max-width: 768px) {",
      "  img[src*='images/generated/'] {",
      "    border-radius: 12px !important;",
      "  }",
      "}",
    ].join("\n");
    document.head.appendChild(style);
  }

  async function clearLocalhostCachesOnce() {
    var isLocal =
      window.location.hostname === "localhost" ||
      window.location.hostname === "127.0.0.1";
    if (!isLocal) return;

    var markKey = "ibridge_runtime_cache_fix_v1";
    if (sessionStorage.getItem(markKey) === "1") return;
    sessionStorage.setItem(markKey, "1");

    try {
      if ("serviceWorker" in navigator) {
        var regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map(function (r) { return r.unregister(); }));
      }
      if ("caches" in window) {
        var keys = await caches.keys();
        await Promise.all(keys.map(function (k) { return caches.delete(k); }));
      }
      // Single reload after cleanup.
      if (!window.location.search.includes("cachefix=1")) {
        var joiner = window.location.search ? "&" : "?";
        window.location.replace(window.location.href + joiner + "cachefix=1");
      }
    } catch (err) {
      console.warn("runtime-fix cache cleanup warning:", err);
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    normalizeNavbarUI();
    setupMobileMenu();
    enforceLogoFallback();
    applyGeneratedImagePolish();
    clearLocalhostCachesOnce();
  });
})();






