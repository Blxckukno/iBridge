"""
iBridge backend API.
"""

import os
import re
import secrets
from datetime import datetime, timedelta

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, get_jwt_identity, verify_jwt_in_request
from sqlalchemy import text

from models import Course, Ticket, User, UserProgress, db
from security_enhancements import (
    AccountSecurityManager,
    ContactFormSchema,
    SecurityConfig,
    SecurityMiddleware,
    SecurityUtils,
    TicketCreationSchema,
    UserLoginSchema,
    UserRegistrationSchema,
    enhanced_jwt_required,
    setup_csp_violation_reporting,
    validate_json,
)

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "Website"))

app = Flask(__name__, static_folder=BASE_DIR, static_url_path="")
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", "change-me-in-production"),
    SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", "sqlite:///ibridge.db"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    JWT_SECRET_KEY=os.environ.get("JWT_SECRET_KEY", "change-me-jwt-in-production"),
    JWT_ACCESS_TOKEN_EXPIRES=timedelta(hours=24),
    JWT_TOKEN_LOCATION=["headers"],
    JWT_COOKIE_SECURE=True,
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=24),
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)

if app.config["SECRET_KEY"] == "change-me-in-production" or app.config["JWT_SECRET_KEY"] == "change-me-jwt-in-production":
    app.logger.warning("Using default secrets. Set SECRET_KEY and JWT_SECRET_KEY environment variables for production.")

db.init_app(app)
jwt = JWTManager(app)
CORS(app, origins=os.environ.get("CORS_ORIGINS", "*").split(","))
security_middleware = SecurityMiddleware(app)
account_security = AccountSecurityManager(db)
setup_csp_violation_reporting(app)


def _has_internal_security_key():
    expected = os.environ.get("INTERNAL_SECURITY_KEY", "").strip()
    provided = request.headers.get("X-Internal-Security-Key", "").strip()
    return bool(expected) and bool(provided) and secrets.compare_digest(expected, provided)


def _user_is_dev_or_it(user):
    if not user:
        return False
    role = (user.role or "").lower()
    department = (user.department or "").lower()
    allowed_roles = {"admin", "developer", "devops", "security", "it"}
    if role in allowed_roles:
        return True
    return any(tag in department for tag in ["it", "dev", "developer", "security", "technology"])


@jwt.expired_token_loader
def expired_token_callback(jwt_header, jwt_payload):
    return jsonify({"error": "Token has expired"}), 401


@jwt.invalid_token_loader
def invalid_token_callback(error):
    return jsonify({"error": "Invalid token"}), 401


@jwt.unauthorized_loader
def missing_token_callback(error):
    return jsonify({"error": "Authorization token required"}), 401


@app.route("/")
def index():
    response = send_from_directory(BASE_DIR, "index.html")
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@app.route("/<path:path>")
def serve_static(path):
    try:
        response = send_from_directory(BASE_DIR, path)
        response.headers["X-Content-Type-Options"] = "nosniff"
        if path.endswith((".css", ".js", ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg")):
            response.headers["Cache-Control"] = "public, max-age=31536000"
        return response
    except Exception:
        return jsonify({"error": "File not found"}), 404


@app.route("/api/register", methods=["POST"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["register"])
@validate_json(UserRegistrationSchema)
def register():
    data = request.validated_json
    password_errors = SecurityUtils.validate_password_strength(data["password"])
    if password_errors:
        return jsonify({"error": "Password does not meet requirements", "details": password_errors}), 400

    if User.query.filter_by(username=data["username"]).first():
        return jsonify({"error": "Username already exists"}), 409
    if User.query.filter_by(email=data["email"]).first():
        return jsonify({"error": "Email already exists"}), 409

    user = User(
        username=data["username"],
        email=data["email"],
        role=data.get("role", "employee"),
        department=data.get("department"),
        password_changed_at=datetime.utcnow(),
        created_at=datetime.utcnow(),
    )
    user.set_password(data["password"])
    db.session.add(user)
    db.session.commit()

    access_token = create_access_token(identity=user.id, additional_claims={"role": user.role, "username": user.username})
    return jsonify({"message": "User registered successfully", "user": user.to_dict(), "access_token": access_token}), 201


@app.route("/api/login", methods=["POST"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["login"])
@validate_json(UserLoginSchema)
def login():
    data = request.validated_json
    identifier = data["username"]
    user = User.query.filter_by(username=identifier).first() or User.query.filter_by(email=identifier).first()
    if not user:
        account_security.log_security_event("LOGIN_ATTEMPT_INVALID_USER", {"identifier": identifier, "ip": request.remote_addr})
        return jsonify({"error": "Invalid credentials"}), 401

    if account_security.is_account_locked(user):
        return jsonify({"error": "Account temporarily locked due to multiple failed login attempts"}), 423
    if not user.is_active:
        return jsonify({"error": "Account is disabled"}), 403
    if not user.check_password(data["password"]):
        account_security.record_failed_login(identifier)
        return jsonify({"error": "Invalid credentials"}), 401

    account_security.record_successful_login(user)
    access_token = create_access_token(
        identity=user.id, additional_claims={"role": user.role, "username": user.username, "department": user.department}
    )
    return jsonify({"message": "Login successful", "user": user.to_dict(), "access_token": access_token})


@app.route("/api/logout", methods=["POST"])
@enhanced_jwt_required
def logout():
    account_security.log_security_event("LOGOUT", {"user_id": get_jwt_identity(), "ip": request.remote_addr})
    return jsonify({"message": "Logout successful"})


@app.route("/api/tickets", methods=["GET"])
@enhanced_jwt_required
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["api_general"])
def get_tickets():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if user.role == "admin":
        tickets = Ticket.query.order_by(Ticket.created_at.desc()).all()
    else:
        tickets = Ticket.query.filter_by(created_by=user_id).order_by(Ticket.created_at.desc()).all()
    return jsonify([ticket.to_dict() for ticket in tickets])


@app.route("/api/tickets", methods=["POST"])
@enhanced_jwt_required
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["api_intensive"])
@validate_json(TicketCreationSchema)
def create_ticket():
    data = request.validated_json
    user_id = get_jwt_identity()
    ticket = Ticket(
        title=data["title"],
        description=data["description"],
        priority=data.get("priority", "medium"),
        category=data.get("category"),
        created_by=user_id,
    )
    db.session.add(ticket)
    db.session.commit()
    return jsonify(ticket.to_dict()), 201


@app.route("/api/tickets/<int:ticket_id>", methods=["PUT"])
@enhanced_jwt_required
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["api_intensive"])
def update_ticket(ticket_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    ticket = Ticket.query.get_or_404(ticket_id)
    if ticket.created_by != user_id and user.role != "admin":
        return jsonify({"error": "Access denied"}), 403

    data = request.get_json(silent=True) or {}
    for field in ["status", "priority", "description", "category"]:
        if field in data:
            setattr(ticket, field, SecurityUtils.sanitize_input(data[field]))
    ticket.updated_at = datetime.utcnow()
    if ticket.status in {"resolved", "closed"} and not ticket.resolved_at:
        ticket.resolved_at = datetime.utcnow()
    db.session.commit()
    return jsonify(ticket.to_dict())


@app.route("/api/courses", methods=["GET"])
@enhanced_jwt_required
def list_courses():
    courses = Course.query.filter_by(is_active=True).all()
    return jsonify([course.to_dict() for course in courses])


@app.route("/api/progress", methods=["GET"])
@enhanced_jwt_required
def get_progress():
    user_id = get_jwt_identity()
    progress = UserProgress.query.filter_by(user_id=user_id).all()
    return jsonify([{"course_id": p.course_id, "progress": p.progress, "last_accessed": p.last_accessed.isoformat()} for p in progress])


@app.route("/api/contact", methods=["POST"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["contact_form"])
@validate_json(ContactFormSchema)
def contact_form():
    return jsonify({"message": "Thank you for your message. We will get back to you soon.", "status": "submitted"})


@app.route("/api/health", methods=["GET"])
def health_check():
    db.session.execute(text("SELECT 1"))
    return jsonify({"status": "healthy", "timestamp": datetime.utcnow().isoformat(), "version": "3.0.0"})


@app.route("/api/security-info", methods=["GET"])
def security_info():
    return jsonify(
        {
            "password_policy": {
                "min_length": SecurityConfig.PASSWORD_MIN_LENGTH,
                "requires_uppercase": SecurityConfig.PASSWORD_REQUIRE_UPPERCASE,
                "requires_lowercase": SecurityConfig.PASSWORD_REQUIRE_LOWERCASE,
                "requires_numbers": SecurityConfig.PASSWORD_REQUIRE_NUMBERS,
                "requires_special": SecurityConfig.PASSWORD_REQUIRE_SPECIAL,
            },
            "account_security": {
                "max_login_attempts": SecurityConfig.MAX_LOGIN_ATTEMPTS,
                "lockout_duration_minutes": int(SecurityConfig.LOCKOUT_DURATION.total_seconds() / 60),
            },
            "rate_limits": SecurityConfig.RATE_LIMITS,
        }
    )


@app.route("/api/analytics", methods=["POST"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["api_general"])
def analytics_ingest():
    payload = request.get_json(silent=True) or {}
    app.logger.info("Analytics event received: %s", str(payload)[:500])
    return jsonify({"status": "accepted"}), 202


@app.route("/api/performance", methods=["POST"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["api_general"])
def performance_ingest():
    payload = request.get_json(silent=True) or {}
    app.logger.info("Performance event received: %s", str(payload)[:500])
    return jsonify({"status": "accepted"}), 202


@app.route("/api/push-subscription", methods=["POST", "DELETE"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["api_general"])
def push_subscription():
    return jsonify({"status": "ok"}), 200


@app.route("/api/security/report", methods=["POST"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["api_general"])
def security_report():
    payload = request.get_json(silent=True) or {}
    account_security.log_security_event("CLIENT_SECURITY_REPORT", {"ip": request.remote_addr, "payload": payload})
    return jsonify({"status": "received"}), 200


@app.route("/api/submit-form", methods=["POST"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["contact_form"])
def submit_form():
    payload = request.get_json(silent=True) or {}
    app.logger.info("Offline form submission received: %s", str(payload)[:500])
    return jsonify({"status": "queued"}), 202


@app.route("/api/sharepoint-tickets", methods=["GET"])
def sharepoint_tickets_feed():
    data_path = os.path.join(BASE_DIR, "data", "sharepoint-tickets.json")
    if not os.path.exists(data_path):
        return jsonify({"error": "SharePoint ticket data file not found"}), 404
    try:
        with open(data_path, "r", encoding="utf-8") as fp:
            return app.response_class(fp.read(), mimetype="application/json")
    except Exception:
        return jsonify({"error": "Unable to read SharePoint ticket data"}), 500


@app.route("/api/security/audit-summary", methods=["GET"])
def security_audit_summary():
    summary = {
        "timestamp": datetime.utcnow().isoformat(),
        "users_total": 0,
        "users_with_failed_logins": 0,
        "users_locked_now": 0,
        "tickets_total": 0,
        "suspicious_tickets_found": 0,
        "security_log_entries": 0,
        "suspicious_log_entries": 0,
    }

    suspicious_pattern = re.compile(
        r"(?i)(SUSPICIOUS_REQUEST_BLOCKED|LOGIN_ATTEMPT_INVALID_USER|CSP_VIOLATION|REQUEST_TOO_LARGE|blocked)"
    )
    db_injection_pattern = re.compile(r"(?i)(<script|javascript:|union\s+select|drop\s+table|onerror=|onload=)")

    try:
        summary["users_total"] = User.query.count()
        summary["users_with_failed_logins"] = User.query.filter(User.failed_login_attempts > 0).count()
        summary["users_locked_now"] = User.query.filter(User.locked_until.isnot(None)).count()
        tickets = Ticket.query.all()
        summary["tickets_total"] = len(tickets)
        summary["suspicious_tickets_found"] = sum(
            1
            for t in tickets
            if db_injection_pattern.search(f"{t.title or ''} {t.description or ''}")
        )
    except Exception:
        pass

    log_path = os.path.join("logs", "security-events.log")
    if os.path.exists(log_path):
        try:
            with open(log_path, "r", encoding="utf-8", errors="ignore") as fp:
                lines = fp.readlines()
            summary["security_log_entries"] = len(lines)
            summary["suspicious_log_entries"] = sum(1 for line in lines if suspicious_pattern.search(line))
        except Exception:
            pass

    return jsonify(summary)


@app.route("/api/security/attacks", methods=["GET"])
@security_middleware.limiter.limit(SecurityConfig.RATE_LIMITS["api_general"])
def security_attacks():
    user = None
    try:
        verify_jwt_in_request(optional=True)
        identity = get_jwt_identity()
        if identity:
            user = User.query.get(identity)
    except Exception:
        user = None

    if not (_user_is_dev_or_it(user) or _has_internal_security_key()):
        return jsonify({"error": "Dev/IT access required"}), 403

    log_path = os.path.join(os.path.dirname(__file__), "..", "..", "logs", "security-events.log")
    log_path = os.path.abspath(log_path)

    suspicious_pattern = re.compile(
        r"(?i)(SUSPICIOUS_REQUEST_BLOCKED|LOGIN_ATTEMPT_INVALID_USER|CSP_VIOLATION|REQUEST_TOO_LARGE|blocked)"
    )
    if not os.path.exists(log_path):
        return jsonify({"source": log_path, "total": 0, "suspicious": 0, "events": []})

    with open(log_path, "r", encoding="utf-8", errors="ignore") as fp:
        lines = fp.readlines()

    events = []
    for line in lines[-500:]:
        text = line.strip()
        if not text:
            continue
        events.append({"line": text, "is_suspicious": bool(suspicious_pattern.search(text))})

    suspicious_count = sum(1 for e in events if e["is_suspicious"])
    return jsonify(
        {
            "source": log_path,
            "total": len(events),
            "suspicious": suspicious_count,
            "events": events[-200:],
        }
    )


def init_db():
    with app.app_context():
        db.create_all()
        admin_user = User.query.filter_by(username="admin").first()
        if not admin_user:
            admin_password = os.environ.get("IBRIDGE_ADMIN_PASSWORD")
            if admin_password:
                admin_user = User(
                    username="admin",
                    email=os.environ.get("IBRIDGE_ADMIN_EMAIL", "admin@ibridge-solutions.com"),
                    role="admin",
                    department="Administration",
                    created_at=datetime.utcnow(),
                    password_changed_at=datetime.utcnow(),
                )
                admin_user.set_password(admin_password)
                db.session.add(admin_user)
                db.session.commit()


if __name__ == "__main__":
    os.makedirs("logs", exist_ok=True)
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=os.environ.get("FLASK_ENV") == "development")
